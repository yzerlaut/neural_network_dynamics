import os, shutil

# import brian2
# LIST = []
# for ff in os.listdir('.'):
#     if ff.endswith('swc'):
#         print(ff)
#         try:
#             morpho = brian2.Morphology.from_swc_file(ff)
#             LIST.append(ff)
#             print(ff, ' accepted')
#         except (ValueError, RecursionError):
#             pass
# print(LIST)

LIST = ['L23BC-j130313b-cell-3.CNG.swc', 'L23BPC-j130930b-cell-1.CNG.swc', 'L23BPC-j140716c-cell-6.CNG.swc', 'L23BPC-j140903a-cell-2.CNG.swc', 'L23BTC-j140828a.CNG.swc', 'L23ChC-j140213a.CNG.swc', 'L23DBC-j140417b-cell-7.CNG.swc', 'L23MC-140827b-cell-3.CNG.swc', 'L23MC-j140718c-cell-2.CNG.swc', 'L23pyr-j150407a.CNG.swc', 'L23pyr-j150811a.CNG.swc', 'L5BC-j130705b-cell-7.CNG.swc', 'L5BC-j131015a-cell-3.CNG.swc', 'L5MC-j120921b.CNG.swc', 'L5MC-j130717a-cell-6.CNG.swc', 'L5pyr-j140408b.CNG.swc', 'L5SC-j131120c-cell4.CNG.swc', 'SBC-like-x121017b-cell-1.CNG.swc', 'SBC-like-x121025b.CNG.swc', 'SBC-like-x121214a.CNG.swc']

for ff in LIST:
    shutil.copy2(ff, 'accepted/')
